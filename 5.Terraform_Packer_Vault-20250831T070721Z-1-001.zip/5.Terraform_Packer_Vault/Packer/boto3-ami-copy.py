import boto3
import datetime
import json
regions = ['us-east-2','ap-south-1']
def lambda_handler(event, context):
    print(event)
    print(event['detail']['ImageId'])
    amiid = event['detail']['ImageId']
    current_date = datetime.datetime.now().date()
    for reg in regions:
        client = boto3.client('ec2',region_name=reg)
        response = client.copy_image(
        Encrypted=False,
        Name='AWSB65-AMI-'+str(current_date),
        SourceImageId=amiid,
        SourceRegion='us-east-1',
        TagSpecifications=[
            {
                'ResourceType': 'image',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'AWSB65-AMI-'+str(current_date),
                    },
                ]
            },
        ]
        )
    
