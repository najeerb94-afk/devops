sudo snap install --classic certbot
certbot certonly --manual --preferred-challenges=dns --key-type rsa \
--email mavrick202@gmail.com --server https://acme-v02.api.letsencrypt.org/directory \
--agree-tos -d *.awsb47.xyz


apt update && apt install -y unzip net-tools
wget https://releases.hashicorp.com/vault/1.13.2/vault_1.13.2_linux_amd64.zip
unzip vault_1.13.2_linux_amd64.zip
cp vault /usr/bin/vault
mkdir -p /etc/vault
mkdir -p /var/lib/vault/data
vault version
nano config.hcl
cp config.hcl /etc/vault/config.hcl
cp vault.service /etc/systemd/system/vault.service
sudo systemctl daemon-reload
sudo systemctl stop vault
sudo systemctl start vault
sudo systemctl enable vault
sudo systemctl status vault --no-pager

ps -ef | grep -i vault | grep -v grep
netstat -nltp | grep -i <PID>
journalctl -u vault

Add Route53 Record for Vault Public IP Address.

export VAULT_ADDR=http://vault.awscloudclass.xyz:8200
echo "export VAULT_ADDR=http://vault.awscloudclass.xyz:8200" >>~/.bashrc

https://devopscube.com/setup-hashicorp-vault-beginners-guide/

vault status
root@vault:~# vault status
Key Value
--- -----
Seal Type shamir
Initialized false
Sealed true
Total Shares 0
Threshold 0
Unseal Progress 0/0
Unseal Nonce n/a
Version 1.13.2
Build Date 2023-02-02T09:07:27Z
Storage Type file
HA Enabled false

vault operator init | tee -a /etc/vault/init.file

vault operator unseal 1K3Bf5jZsiafC5DMyP2EFfVBE7bNee/1RNt2GFh3pm2B
vault operator unseal vervY+s7xiPMEs+d6tRpgFhxWSMdaSf/Cz/WPYvvWE7i
vault operator unseal fDYu0K1U5XsrTYqvres7cOl/Q/pMOjzSqIpMWdlhwazF

Initial Root Token: hvs.tJjgSXdnst12wo9VJhtLznSO

vault status

root@vault:~# vault status
Key Value
--- -----
Seal Type shamir
Initialized true
Sealed false
Total Shares 5
Threshold 3
Version 1.13.2
Build Date 2023-02-02T09:07:27Z
Storage Type file
Cluster Name vault
Cluster ID c6d48ce8-7ce5-31ae-20a8-1e5396785a45

sudo snap install --classic certbot
certbot certonly --manual --preferred-challenges=dns --email mavrick202@gmail.com \
--key-type rsa \
--server https://acme-v02.api.letsencrypt.org/directory --agree-tos -d *.awsb47.xyz
