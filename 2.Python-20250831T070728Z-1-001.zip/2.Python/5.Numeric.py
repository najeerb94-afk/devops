a = 10
b = 10.5
c = 5j
print(type(a))
print(type(b))
print(type(c))

#BODMAS (or sometimes BOMDAS), standing for Brackets, Of, Division/Multiplication, Addition/Subtraction.

#Arithmetic Operators:
Addition = 10 + 5
Subtraction = 10 - 5
Multiplication = 10 * 5
Division = 10 / 5
Modulus = 10 % 5
Exponential = 10 ** 5
Floor_Division = 10 // 5
Increment = I+=1 (or) I = I+1
Decrement = I-=1 (or) I = I-1
