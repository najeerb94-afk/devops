# List
aws_regions = ['us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1']

len(aws_regions) #To get the length of a list.
aws_regions[0] #To get the first element of a list.
aws_regions.append('ap-south-1') #To add an element to the end of a list.
aws_regions.insert(1,'megastar') #To add an element at a specific index.
aws_regions.pop() #To remove the last element of a list.
aws_regions.pop(1) #To remove an element at a specific index.
aws_regions.remove('us-west-2') #To remove an element by value.
new_regions_list_1= aws_regions #To copy a list with reference. Means if we change the new_regions_list_1 then aws_regions will also change.
new_regions_list_2 = aws_regions.copy() #To copy a new list without reference. Means if we change the new_regions_list_2 then aws_regions will not change.
aws_regions.reverse() #To reverse the list.
aws_regions.clear() #To clear the list.
aws_regions.sort() #To sort the list in ascending order.(reverse=True for descending order)
aws_regions.count('us-east-1') #To count the number of times an element is repeated in a list.

new_aws_regions = ['ap-south-1','eu-west-2','ap-south-2']
aws_regions.extend(new_aws_regions) #To new list to an existing list.


#Tuple
tup_aws_regions = ('us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1')
type(tup_aws_regions) 
tup_aws_regions.index('us-west-1') #To get the index of an element in a tuple.
tup_aws_regions.count('us-west-2') #To count the number of times an element is repeated in a tuple.
import sys
sys.getsizeof(tup_aws_regions) #To get the size of a tuple 72 bytes.
sys.getsizeof(aws_regions) #To get the size of a list 88 bytes.

#Range
range(10) #To generate a range of numbers from 0 to 9.
range(1,10) #To generate a range of numbers from 1 to 9.
range(1,10,2) #To generate a range of numbers from 1 to 9 with a step of 2.
list(range(10)) #To convert a range in to a list.

#Get VPC ID's from AWS Regions using List:
#pip install boto3
import boto3
aws_regions = ['us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1']
for region in aws_regions:
    region_vpc_list = []
    ec2_client = boto3.client('ec2', region_name=region)
    vpclist = ec2_client.describe_vpcs().get('Vpcs',[])
    for vpc in vpclist:
        region_vpc_list.append(vpc.get('VpcId'))
    print(f"Lets Print VPC List For The Region {region}")
    print(region_vpc_list)
    print('-'*140)
    
#Using Tuple:
import boto3
aws_regions = ('us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1')
for region in aws_regions:
    region_vpc_list = []
    ec2_client = boto3.client('ec2', region_name=region)
    vpclist = ec2_client.describe_vpcs().get('Vpcs',[])
    for vpc in vpclist:
        region_vpc_list.append(vpc.get('VpcId'))
    region_vpc_list_tuple = tuple(region_vpc_list)
    print(f"Lets Print VPC Tuple For The Region {region}")
    print(region_vpc_list_tuple)
    print('-'*140)
