quote1 = "Welcome To DevSecOps Training - Python Module."
type(quote1)

quote2 = 'Welcome To DevSecOps Training - Python Module.'
type(quote1)

quote3 = """
Welcome To
DevSecOps Training
In Telugu
For
Python Module.
"""
type(quote1)

#Substitution of values in a string:
age = 25
country = "India"
print("The person age is %d and he is from %s" % (age, country))

#Using f-string:
print(f"The person age is {age} and he is from {country}.")

#String Methods:
quote1 = "Welcome To DevSecOps Training - Python Module."
type(quote1) #To get the type of a variable.
dir(quote1) #To get all the methods of a string.
help(quote1.split())

#To get the length of a string:
len(quote1)
quote1.__len__()
quote1.lower()
quote1.casefold() #To convert the string to lowercase.
quote1.upper()
quote1.title() #To capitalize the first letter of each word.
quote1.capitalize() #To capitalize the first letter of the string.
quote1.count("o") #To count the number of times a character is repeated in a string.
quote1.replace("DevSecOps","DevOps") #To replace a string with another string.
quote1.find("DevSecOps") #From where DevSecOps is starting in the string.
quote1.swapcase() #Convert Lowercase to Uppercase and Uppercase to Lowercase.

#Convert a string in to Array or List:
quote1.split() #By default it will split the string by space.
quote1.split("/") #To split the string by a delimiter like /.

#Removing the white spaces from the string:
x = '    Welcome-To-DevSecOps-Training-In-Telugu     '
x.strip() #To remove the white spaces from both sides.
x.lstrip() #To remove the white spaces from left side.
x.rstrip() #To remove the white spaces from right side.

#Join items in a list or tuple:
my_friends = ['Ravi', 'Kiran', 'Suresh', 'Rajesh']
my_friends_str = '-'.join(my_friends)
print(my_friends_str)


if x.islower():
    print("Quote1 Is Lower")
else:
    print("NOT LOWER")