#If I have a JSON String and I want to convert it to a Python object, I can use the json.loads() method.
import json
aws_cloud = '''{
    "name": "Amazon Web Services",
    "parent": "Amazon",
    "founded": 1994,
    "founder": "Jeff Bezos",
    "headquarters": "Seattle, Washington, U.S.",
    "services": ["EC2", "S3", "RDS", "Lambda", "DynamoDB"],
    "still_active": "True"
}'''

json.loads(aws_cloud)

#Image I have a file with JSON data and I need to read it and convert it to a Python object, I can use the json.load() method.
#Loading a JSON File and converting it to a Python object.

with open('/tmp/ip.json','r') as f:
    x = json.load(f)
    print(x.keys())
    for item in x['values']:
        print(item['name'],'---->',item['properties']['addressPrefixes'])
        print("*"*120)
