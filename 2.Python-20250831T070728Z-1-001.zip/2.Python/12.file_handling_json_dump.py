#Python file handling can be done in two ways:
#Old way: Using file object.
#New way: Using with statement.

#Reading file in old way:
f = open('/tmp/data') (or) f = open('/tmp/data','rt') #both are same.
f.readlines()
f.close()

#Old way of writing a file:
import json
from faker import Faker
data = Faker()
f = open('/tmp/profile','wt')
profile = data.profile()
json_profile = json.dumps(profile,default=str,indent=2)
f.write(str(json_profile))
f.close()

#New way of reading a file:
import json
from faker import Faker
data = Faker()
with open('/tmp/profile',"a+") as f:
    profile = data.profile()
    json_profile = json.dumps(profile,default=str,indent=2)
    f.write(str(json_profile))
    
    
# Using json.dump() to write a file:
import json
from faker import Faker
data = Faker()
with open('/tmp/jsondump',"a+") as f:
    profile = data.profile()
    json.dump(profile,f,indent=2,default=str)