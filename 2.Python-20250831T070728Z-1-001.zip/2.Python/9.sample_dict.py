aws_cloud ={
    'name': 'Amazon Web Services',
    'parent': 'Amazon',
    'founded': 1994,
    'founder': 'Jeff Bezos',
    'headquarters': 'Seattle, Washington, U.S.',
    'services': ['EC2', 'S3', 'RDS', 'Lambda', 'DynamoDB'],
    'still_active': True
}

type(aws_cloud) #dict
aws_cloud.keys() #To get the keys of a dictionary.
aws_cloud.values() #To get the values of a dictionary.
aws_cloud.items() #To get the items of a dictionary.
aws_cloud.popitem() #To remove the last item of a dictionary.
aws_cloud.pop('founder') #To remove an item from a dictionary by key.
aws_cloud.get('services') #To get the value of a key from a dictionary.
aws_cloud['services'] #To get the value of a key from a dictionary.
aws_cloud.update({"others": ["whole foods","Blue Origin"]}) #To add a new key value pair to a dictionary.
aws_cloud.clear() #To clear the dictionary.

x = list(range(1,5))
newdict = dict.fromkeys(x,'default')


#Creating a dictionary from two lists.
x = list(range(1,5))
y = ['us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1']
z = dict(zip(x,y))

#Looping through a dictionary.
for key,value in aws_cloud.items():
    print(f"Key: {key} ---> Value: {value}")
    
for k,v in aws_cloud.items():
    print(f"{k} ---> {v}")
