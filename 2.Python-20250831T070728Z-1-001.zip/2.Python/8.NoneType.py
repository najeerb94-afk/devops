a = 10
b = 20
c = print(a+b)
#print dont return anything so it is NoneType.

c = a+b
print(c)