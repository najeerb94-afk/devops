# Python JSON module has two main methods:
#json.dumps() #To convert a Python object to a JSON string.
#json.dump() #To write a Python object to a JSON file.
#json.loads() #To convert a JSON string to a Python object.
#json.load() #To read a JSON file to a Python object.

aws_cloud = {
    'name': 'Amazon Web Services',
    'parent': 'Amazon',
    'founded': 1994,
    'founder': 'Jeff Bezos',
    'headquarters': 'Seattle, Washington, U.S.',
    'services': ['EC2', 'S3', 'RDS', 'Lambda', 'DynamoDB'],
    'still_active': True
}

x = json.dumps(aws_cloud) #To convert a Python object to a JSON string.
y = json.loads(x) #To convert a JSON string to a Python object.

#Refer to 12.file_handling.py for json.dump() and json.load() methods.