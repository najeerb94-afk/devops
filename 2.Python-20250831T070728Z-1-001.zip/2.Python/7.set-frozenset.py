#Set is a collection of unique elements. It is unordered and unindexed.
friends = {'Ravi', 'Kiran', 'Suresh', 'Rajesh'}
friends.add('Anand') #To add an element to a set.
friends.pop() #To remove an element from a set.
friends.remove('Kiran') #To remove an element from a set. If not present it will throw an KeyError.
friends.discard('Rajesh') #To remove an element from a set. If not present it will not throw an error.

friends1.update(friends2) #To add elements of one set to another set.
friends1.union(friends2) #To get the union of two sets.
#I want to take a list and remove duplicates from it and then convert it to a tuple.
data = list(range(1,10))
data.extend(data)
data.extend(data)

unique_data = tuple(set(data))
unique_data

friends1 = {'Ravi', 'Kiran', 'Suresh', 'Rajesh'}
friends2 = {'Ravi1', 'Kiran1', 'Suresh1', 'Anand1'}

aws_regions = ['us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1']
frozen = frozenset(aws_regions) #To create a frozen set.